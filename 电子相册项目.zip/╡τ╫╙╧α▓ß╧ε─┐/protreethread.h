#ifndef PROTREETHREAD_H
#define PROTREETHREAD_H
#include <QThread>
#include <QObject>
#include <QTreeWidgetItem>
#include <QTreeWidget>
class ProTreeThread : public QThread
{
    Q_OBJECT
public:

    explicit ProTreeThread(const QString &src_path, const QString & dist_path, QTreeWidgetItem *parent_item,
                           int &file_count,QTreeWidget* self,QTreeWidgetItem* root, QObject *parent = nullptr);
    //参数：原地址，目的地址，父亲节点，文件数，左边布局的widget，

    ~ProTreeThread();
protected:
     virtual void run();    //自己线程的实际运行的东西
private:
     void CreateProTree(const QString& src_path, const QString& dist_path,
                              QTreeWidgetItem* parent_item,
                              int &file_count, QTreeWidget* self, QTreeWidgetItem* root, QTreeWidgetItem* preItem = nullptr);
    //创建一个树

    QString _src_path;
    QString _dist_path;
    int _file_count;
    QTreeWidgetItem * _parent_item;
    QTreeWidget* _self;
    QTreeWidgetItem* _root;
    bool _bstop;

public slots:
    void SlotCancelProgress();

signals:
    void SigUpdateProgress(int);
    void SigFinishProgress(int);

};

#endif // PROTREETHREAD_H
