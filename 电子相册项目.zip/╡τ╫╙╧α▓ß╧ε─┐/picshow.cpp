#include "picshow.h"
#include "ui_picshow.h"
#include <QPixmap>
#include <QDir>
#include <QImage>
#include <QEvent>
#include "picbutton.h"
#include <QDebug>

PicShow::PicShow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PicShow),_selected_path(""),_b_btnvisible(false)
{
    ui->setupUi(this);
    ui->previousBtn->SetIcons(":/icon/previous.png",
                              ":/icon/previous_hover.png",
                              ":/icon/previous_press.png");

    ui->nextBtn->SetIcons(":/icon/next.png",
                              ":/icon/next_hover.png",
                              ":/icon/next_press.png");

    //发前后信号点击后的信号
    connect(ui->nextBtn,&QPushButton::clicked,this, &PicShow::SigNextClicked);
    connect(ui->previousBtn,&QPushButton::clicked,this, &PicShow::SigPreClicked);

    QGraphicsOpacityEffect *opacity_pre = new QGraphicsOpacityEffect(this);     //定义透明度效果
    opacity_pre->setOpacity(0);     //设置透明度0.5,透明范围：[0,1]
    ui->previousBtn->setGraphicsEffect(opacity_pre);    //设置ui器件的透明度

    QGraphicsOpacityEffect *opacity_next = new QGraphicsOpacityEffect(this);
    opacity_next->setOpacity(0); //设置透明度0.5,透明范围：[0,1]
    ui->nextBtn->setGraphicsEffect(opacity_next);


    //使用属性动画类让控件在透明度范围内变化
    _animation_show_pre = new QPropertyAnimation(opacity_pre, "opacity",this);  //把动画的透明度设置到动画中
    _animation_show_pre->setEasingCurve(QEasingCurve::Linear);
    _animation_show_pre->setDuration(500); //动效时长3s

    _animation_show_next = new QPropertyAnimation(opacity_next, "opacity",this);
    _animation_show_next->setEasingCurve(QEasingCurve::Linear);
    _animation_show_next->setDuration(500); //动效时长3s

}

PicShow::~PicShow()
{
    delete ui;
}

//重绘窗口大小，以及重新加载图片
void PicShow::ReloadPic()
{
   if(_selected_path != ""){
     const auto &width = ui->gridLayout->geometry().width();
     const auto &height = ui->gridLayout->geometry().height();  //获取布局的高度、宽度
     _pix_map.load(_selected_path);     //加载已选中的图片文件

     _pix_map = _pix_map.scaled(width,height,Qt::KeepAspectRatio);  //拉伸
     ui->label->setPixmap(_pix_map);    //ui界面标签加载此图片
   }
}


//重写鼠标放到按钮上的事件
bool PicShow::event(QEvent *event)
{
    switch (event->type()){

        case QEvent::Enter:
            ShowPreNextBtns(true);      //滑动进入，显示按钮
            break;
        case QEvent::Leave:
            ShowPreNextBtns(false);     //滑动离开，隐藏按钮
            break;
        default:
            break;
    }
    return QDialog::event(event);       //调用基类的
}

void PicShow::ShowPreNextBtns(bool b_show)
{
    if(!b_show&&_b_btnvisible){     //如果要求隐藏且当前按钮是显示状态

        _animation_show_pre->stop();        //停掉动画
        //然后设置动画从1显示变为0隐藏，设置完毕后启动动画
        _animation_show_pre->setStartValue(1);
        _animation_show_pre->setEndValue(0);
        _animation_show_pre->start();

        _animation_show_next->stop();
        _animation_show_next->setStartValue(1);
        _animation_show_next->setEndValue(0);
        _animation_show_next->start();
        _b_btnvisible = false;      //改变当前状态
        return;
    }

    if(_selected_path ==""){
        return;
    }

    if(b_show&&!_b_btnvisible){     //如果要求显示且当前隐藏，和上述相反即可
        _animation_show_pre->stop();
       _animation_show_pre->setStartValue(0);
       _animation_show_pre->setEndValue(1);
       _animation_show_pre->start();

       _animation_show_next->stop();
       _animation_show_next->setStartValue(0);
       _animation_show_next->setEndValue(1);
       _animation_show_next->start();
       _b_btnvisible = true;
    }

}


void PicShow::SlotSelectItem(const QString& path)
{
    _selected_path = path;      //更新选中的路径

    _pix_map.load(path);        //图片地址加载
    //图片稍微比picshow宽度少一点
    auto width = this->width()-20;
    auto height = this->height()-20;
    _pix_map = _pix_map.scaled(width,height,Qt::KeepAspectRatio);   //等比例拉伸，保证长宽比例不变
    ui->label->setPixmap(_pix_map);     //往之前label中加载存储图片

}

void PicShow::SlotDeleteItem()
{
    _selected_path = "";    //把item的路径清空实现图片下一次消失
}

void PicShow::SlotUpdatePic(const QString &_path)
{
    //把更新后的item路径替换为已选中的item路径，
    _selected_path = _path;
    if(_selected_path != ""){
      const auto &width = ui->gridLayout->geometry().width();
      const auto &height = ui->gridLayout->geometry().height();
      _pix_map.load(_selected_path);

      _pix_map = _pix_map.scaled(width,height,Qt::KeepAspectRatio);
      ui->label->setPixmap(_pix_map);
    }
}




