#include "prelistwid.h"
#include "protreeitem.h"
#include "prelistitem.h"
#include "const.h"
#include <QDebug>
#include <QPainter>
#include "const.h"
#include <QGuiApplication>

PreListWid::PreListWid(QWidget *parent):QListWidget(parent),_global(0),_last_index(17)
{
    this->setViewMode(QListWidget::IconMode);           //设置内容为图片
    this->setIconSize(QSize(PREICON_SIZE, PREICON_SIZE));//设置图片的大小
    this->setSpacing(5);                                //设置每个item之间的间隔大小
    connect(this,&PreListWid::itemPressed, this, &PreListWid::SlotItemPressed);
}

PreListWid::~PreListWid()
{

}

//对此路径的item进行识别，画出符合预览大小的item图片展示
void PreListWid::AddListItem(const QString &path)
{
    QPixmap src_pixmap(path);
    src_pixmap = src_pixmap.scaled(PREICON_SIZE,PREICON_SIZE,Qt::KeepAspectRatio);      //当前图片等比拉伸
    QPixmap dst_pixmap(QSize(PREICON_SIZE, PREICON_SIZE));      //目的图片大小
    auto src_width = src_pixmap.width();
    auto src_height = src_pixmap.height();
//    qDebug() << "src_pixmap.width is " << src_width
//             << " src_pixmap.height is " << src_height;
    auto dist_width = dst_pixmap.width();
    auto dist_height = dst_pixmap.height();
//    qDebug() << "dst_pixmap.width is " << dist_width
//             << " dst_pixmap.height is " << dist_height;

    dst_pixmap.fill(QColor(220,220,220, 50));   //填充目标图片的背景
    QPainter painter(&dst_pixmap);      //画刷加载此图片

    auto x = (dist_width-src_width)/2;
    auto y = (dist_height-src_height)/2;    //设置画的图片能够居中画在目的图片中
    painter.drawPixmap(x,y,src_pixmap);     //画出原图片到目标图片

    _global++;
    PreListItem *pItem = new PreListItem(QIcon(dst_pixmap),path,_global,this);
    pItem->setSizeHint(QSize(PREITEM_SIZE,PREITEM_SIZE));       //设置Item的默认大小
    this->addItem(pItem);
    _set_items[path] = pItem;                                   //在集合中加入item

    if(_global==1){     //第一张图片的时候
        _pos_origin = this->pos();      //记录他的位置
    }
}

void PreListWid::SlotItemPressed(QListWidgetItem *item)
{
    if(QGuiApplication::mouseButtons() != Qt::LeftButton){
        return;
    }

    //获取item和当前索引以及路径
    auto * list_item = dynamic_cast<PreListItem*>(item);
    auto cur_index = list_item->GetIndex();
    auto path = list_item->GetPath();

//    //每隔18个是一组，一组同屏显示不需要跳转
//    if(cur_index/18 == _last_index/18){
//        this->setCurrentItem(item);
//        emit SigUpSelectShow(path);
//        return;
//    }

//    if(cur_index > 17){
//        auto pos_cur = this->pos();
//        this->move(pos_cur.x()-(cur_index-_last_index)*100, pos_cur.y());
//        _last_index = cur_index;

//    }else{
////        auto pos_cur = this->pos();
////        qDebug()<< "pos_cur is " << pos_cur << "origin_point is " << _origin_point << endl;
//       this->move(_pos_origin);
//        _last_index = 17;
//    }

     this->setCurrentItem(item);
    emit SigUpSelectShow(path);     //发送选择显示预览图的信号
}



void PreListWid::SlotUpPreList(QTreeWidgetItem *tree_item)
{
    if(!tree_item){
        qDebug() << "tree_item is empty" << endl;
        return;
    }

    auto * pro_item = dynamic_cast<ProTreeItem*>(tree_item);
    auto path = pro_item->GetPath();
    auto iter = _set_items.find(path);
    if(iter != _set_items.end()){           //这里是判断item是否存在
        qDebug() << "path " <<path<< " exists" << endl;
        return;
    }

    AddListItem(path);      //把路径加入item集合，使得此item绘制成图片
}

void PreListWid::SlotUpSelect(QTreeWidgetItem *tree_item)
{
    if(!tree_item){
        qDebug() << "tree_item is empty" << endl;
        return;
    }

    auto * pro_item = dynamic_cast<ProTreeItem*>(tree_item);
    auto path = pro_item->GetPath();
    auto iter = _set_items.find(path);
    if(iter == _set_items.end()){
        qDebug() << "path " <<path<< " not exists" << endl;
       // this->setCurrentItem(iter.value());
        return;
    }

    auto * list_item = dynamic_cast<PreListItem*>(iter.value());
    auto index = list_item->GetIndex();

    if(index > 17){     //当预览的图片数>17后
        auto pos_cur = this->pos();
        this->move(pos_cur.x()-(index-_last_index)*100, pos_cur.y());   //实现整个窗口往左移动一个Item
        _last_index = index;

    }else{
//        auto pos_cur = this->pos();
//        qDebug()<< "pos_cur is " << pos_cur << "origin_point is " << _origin_point << endl;
       this->move(_pos_origin);
        _last_index = 17;
    }
    this->setCurrentItem(iter.value());     //设置当前窗口的item
}
