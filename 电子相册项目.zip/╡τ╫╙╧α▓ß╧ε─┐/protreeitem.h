#ifndef PROTREEITEM_H
#define PROTREEITEM_H
#include <QTreeWidgetItem>
#include <QTreeWidget>
#include <QString>

class ProTreeItem:public QTreeWidgetItem
{
public:
    ProTreeItem(QTreeWidget *view, const QString & name, const QString & path,int type = Type);
    ProTreeItem(QTreeWidgetItem *parent, const QString & name, const QString & path,
                QTreeWidgetItem* root, int type = Type);
    const QString& GetPath();
    QTreeWidgetItem* GetRoot();
    void SetPreItem(QTreeWidgetItem* item);
    void SetNextItem(QTreeWidgetItem* item);
    ProTreeItem* GetPreItem();
    ProTreeItem* GetNextItem();
    ProTreeItem* GetLastPicChild();
    ProTreeItem* GetFirstPicChild();
private:
    QString _path;
    QString _name;
    QTreeWidgetItem* _root;     //根节点
    QTreeWidgetItem* _pre_item;     //前一个节点
    QTreeWidgetItem* _next_item;    //后一个节点
};

#endif // PROTREEITEM_H
