#include "protreeitem.h"
#include "const.h"
ProTreeItem::ProTreeItem(QTreeWidget *view, const QString &name,
                         const QString &path, int type):QTreeWidgetItem (view, type),
    _path(path),_name(name),_root(this),_pre_item(nullptr),_next_item(nullptr)
{
    //protreeItem的构造函数
}

ProTreeItem::ProTreeItem(QTreeWidgetItem *parent, const QString &name,
                         const QString &path, QTreeWidgetItem* root,int type):QTreeWidgetItem(parent,type),
    _path(path),_name(name),_root(root),_pre_item(nullptr),_next_item(nullptr)

{
    //构造函数2，当有父节点存在的时候，子item的构造
}

const QString &ProTreeItem::GetPath()
{
    return _path;
}

QTreeWidgetItem *ProTreeItem::GetRoot()
{
    return _root;
}

void ProTreeItem::SetPreItem(QTreeWidgetItem *item)
{
    //设置前向节点
    _pre_item = item;
}

void ProTreeItem::SetNextItem(QTreeWidgetItem *item)
{
    //设置后向节点
    _next_item = item;
}

ProTreeItem *ProTreeItem::GetPreItem()
{
    return  dynamic_cast<ProTreeItem*>(_pre_item);
    //设置成员时是基类的变量，返回值是子类，因此需要设置隐式转换
}

ProTreeItem *ProTreeItem::GetNextItem()
{
    return  dynamic_cast<ProTreeItem*>(_next_item);
}

ProTreeItem *ProTreeItem::GetLastPicChild()
{
    if(this->type() == TreeItemPic){    //如果刚好是图片类型，返回空
        return nullptr;
    }

    auto child_count = this->childCount();  //获取当前根下的子节点数目，文件夹数目
    if(child_count == 0){
        return nullptr;
    }

    for(int i = child_count-1; i >= 0; i--){
        auto* last_child = this->child(i);
        auto * last_tree_item = dynamic_cast<ProTreeItem*>(last_child);     //最后一个item
        int item_type = last_tree_item->type();

        if(item_type == TreeItemPic){   //如果是图片，返回此item
            return last_tree_item;
        }

        last_child = last_tree_item->GetLastPicChild();     //如果是文件夹，递归
        if(!last_child){
            continue;
        }

//        last_tree_item = dynamic_cast<ProTreeItem*>(last_child);        //？？？能不能删除
//        return last_tree_item;            //好像没有影响效果
    }

    return nullptr;     //如果遍历完都没返回值，返回空
}

ProTreeItem *ProTreeItem::GetFirstPicChild()
{
    if(this->type() == TreeItemPic){
        return nullptr;
    }

    auto child_count = this->childCount();
    if(child_count == 0){
        return nullptr;
    }

    for(int i = 0; i < child_count; i++){
        auto * first_child = this->child(i);
        auto * first_tree_child = dynamic_cast<ProTreeItem*>(first_child);
        auto item_type = first_tree_child->type();
        if(item_type == TreeItemPic){
            return first_tree_child;
        }

        first_child = first_tree_child->GetFirstPicChild();
        if(!first_child){
            continue;
        }

        first_tree_child = dynamic_cast<ProTreeItem*>(first_child);
        return first_tree_child;
    }

    return nullptr;
}
