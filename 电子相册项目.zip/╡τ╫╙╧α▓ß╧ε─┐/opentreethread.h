#ifndef OPENTREETHREAD_H
#define OPENTREETHREAD_H

#include <QThread>
#include <QObject>
#include <QTreeWidgetItem>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QDir>
class OpenTreeThread:public QThread
{
     Q_OBJECT
public:
    explicit OpenTreeThread(const QString&src_path, int &file_count,
                           QTreeWidget* self,QObject *parent = nullptr);


    void OpenProTree(const QString &src_path,
                                    int &file_count, QTreeWidget *self);        //写一个打开树的操作
protected:
     virtual void run();
private:
    //递归创建目录树
    void RecursiveProTree(const QString &src_path,      //要导入的路径
                          int &file_count, QTreeWidget *self,       //给哪个widget添加
                          QTreeWidgetItem* root, QTreeWidgetItem* parent, QTreeWidgetItem* preitem);
    QString _src_path;
    int _file_count;
    QTreeWidget* _self;
    bool _bstop;
    QTreeWidgetItem* _root;
signals:
     void SigFinishProgress(int);
     void SigUpdateProgress(int);
};

#endif // OPENTREETHREAD_H
