#include "protreethread.h"
#include <QDir>
#include "protreeitem.h"
#include "const.h"
#include <QFileDialog>
#include <QFileInfo>
#include <QFile>
#include <QDebug>
#include "protreewidget.h"

ProTreeThread::ProTreeThread(const QString &src_path, const QString &dist_path,
                             QTreeWidgetItem *parent_item, int &file_count,
                             QTreeWidget *self, QTreeWidgetItem *root, QObject *parent)
    :QThread (parent),_src_path(src_path),_dist_path(dist_path),
      _file_count(file_count),_parent_item(parent_item),_self(self),_root(root),_bstop(false)
{

}


ProTreeThread::~ProTreeThread()
{

}

void ProTreeThread::run()
{
    CreateProTree(_src_path,_dist_path,_parent_item,_file_count,_self,_root);
    if(_bstop){
        auto path = dynamic_cast<ProTreeItem*>(_root)->GetPath();   //根目录的路径
        auto index = _self->indexOfTopLevelItem(_root);
        delete _self->takeTopLevelItem(index);
        QDir dir(path);
        dir.removeRecursively();        //递归的删除之前拷贝或者未拷贝的文件
        return;
    }

    emit SigFinishProgress(_file_count);
}

//创建目录树
void ProTreeThread::CreateProTree(const QString &src_path, const QString &dist_path,
                                  QTreeWidgetItem *parent_item, int &file_count,
                                  QTreeWidget *self, QTreeWidgetItem *root, QTreeWidgetItem* preItem)
{
    if(_bstop){ //在关键逻辑点会判断，为true就退出
        return;
    }
    bool needcopy = true;       //是否需要拷贝
    if(src_path == dist_path){  //如果原路径和目的路径相等
        needcopy = false;
    }

    QDir import_dir(src_path);      //设置导入路径从原路径处
    qDebug() << "src_path is " << src_path << "dis_path is " << dist_path << endl;
    //设置文件过滤器
    QStringList nameFilters;
    import_dir.setFilter(QDir::Dirs|QDir::Files|QDir::NoDotAndDotDot);//除了目录或文件，其他的过滤掉
    import_dir.setSorting(QDir::Name);  //导入排序，按照文件夹的名字
    QFileInfoList list = import_dir.entryInfoList();    //返回过滤器过滤后的所有一级有效文件和文件夹
    qDebug() << "list.size " << list.size() << endl;

    //遍历
    for(int i = 0; i < list.size(); i++){
        if(_bstop){
            return;
        }
        QFileInfo fileInfo = list.at(i);    //依次取到，有可能是文件夹或者文件
        bool bIsDir = fileInfo.isDir();     //判断是不是目录(文件夹)
        if (bIsDir)
        {
            if(_bstop){
                return;
            }
            file_count++;
            emit SigUpdateProgress(file_count);
            //qDebug()<< "fileInfo.fileName()" << fileInfo.fileName();
//            qDebug()<< "fileInfo.absoluteFilePath() " << fileInfo.absoluteFilePath();
//            qDebug()<< "fileInfo.absolutePath() " << fileInfo.absolutePath();

            QDir dist_dir(dist_path);
            //构造子目的路径               //取得原路径下的文件夹名字
            QString sub_dist_path = dist_dir.absoluteFilePath(fileInfo.fileName());     //将原路径和目的路径进行整合拼接
            qDebug()<< "sub_dist_path " << sub_dist_path;

            //这里是把子文件夹创建进protree主文件下了
            //根据原子文件夹拼接的地址创建新的目录
            QDir sub_dist_dir(sub_dist_path);

            //不存在则创建，比如路径是a/b/c/文件名；但是只有a/b，那就通过此处实现剩下的创建
            if(!sub_dist_dir.exists()){
                //可以创建多级目录
                bool ok = sub_dist_dir.mkpath(sub_dist_path);
                if(!ok){
                    qDebug()<< "sub_dist_dir mkpath failed"<< endl;
                    continue;
                }
            }

            auto * item = new ProTreeItem(parent_item, fileInfo.fileName(),
                                          sub_dist_path, root,TreeItemDir);
            item->setData(0,Qt::DisplayRole, fileInfo.fileName());
            item->setData(0,Qt::DecorationRole, QIcon(":/icon/dir.png"));
            item->setData(0,Qt::ToolTipRole, sub_dist_path);

            CreateProTree(fileInfo.absoluteFilePath(), sub_dist_path, item, file_count, self,root,preItem);     //递归子文件夹下面的各个文件

         }else{
            if(_bstop){
                return;
            }
            const QString & suffix = fileInfo.completeSuffix();     //取出文件完整后缀
            if(suffix != "png" && suffix != "jpeg" && suffix != "jpg"){
                qDebug() << "suffix is not pic " << suffix << endl;
                continue;
            }
            file_count++;   //是的话文件数++
            emit SigUpdateProgress(file_count);
            if(!needcopy){
                continue;
            }

            QDir dist_dir(dist_path);       //创建指向目的目录的对象，然后对此对象进行操作
            //把目的文件地址和要拷贝的文件拷贝成一个新的目的路径
            QString dist_file_path = dist_dir.absoluteFilePath(fileInfo.fileName());

            if(!QFile::copy(fileInfo.absoluteFilePath(), dist_file_path)){
                //copy是复制文件的方法,第一个参数：被复制文件的绝对路径；第二个参数：目标文件的路径
                qDebug() << "file src to dist  copy failed" << endl;
                continue;
            }

            auto * item = new ProTreeItem(parent_item, fileInfo.fileName(),
                                          dist_file_path, root,TreeItemPic);
            item->setData(0,Qt::DisplayRole, fileInfo.fileName());  //展示的角色（字符串），文件名
            item->setData(0,Qt::DecorationRole, QIcon(":/icon/pic.png"));
            item->setData(0,Qt::ToolTipRole, dist_file_path);

            //将Item当做链表串起来，方便实现以后的图片前移和后移
            if(preItem){
                auto* pre_proitem = dynamic_cast<ProTreeItem*>(preItem);
                pre_proitem->SetNextItem(item);
            }

            item->SetPreItem(preItem);
            preItem = item;
         }
    }

   //  dynamic_cast<ProTreeWidget*>(self)->SlotFinishProgress();
    parent_item->setExpanded(true);
}


void ProTreeThread::SlotCancelProgress()
{
    this->_bstop = true;
}
