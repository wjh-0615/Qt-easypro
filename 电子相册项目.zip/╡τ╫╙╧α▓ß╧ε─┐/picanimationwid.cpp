#include "picanimationwid.h"
#include <QPainter>
#include "protreeitem.h"
#include <QDebug>
PicAnimationWid::PicAnimationWid(QWidget *parent) : QWidget(parent),_factor(0.0),
    _cur_item(nullptr),_b_start(false)
{
    _timer = new QTimer(this);
    connect(_timer, &QTimer::timeout, this, &PicAnimationWid::TimeOut);     //动画这个类当定时器超时后执行的操作
}

PicAnimationWid::~PicAnimationWid(){
    _timer->stop();
  //  delete _timer;
}

//设置当前播放和即将播放的图片
void PicAnimationWid::SetPixmap(QTreeWidgetItem *item)
{
    if(!item){
        return;
    }

    auto * tree_item = dynamic_cast<ProTreeItem*>(item);
    auto path = tree_item->GetPath();
    _pixmap1.load(path);
    _cur_item = tree_item;
    if(_map_items.find(path) == _map_items.end()){  //如果在item集合中没有找到此item，说明是第一次要播放，
        _map_items[path]=tree_item;                 //存放进集合中
        qDebug() << "SetPixmap path is " << path << endl;
        //发送更新预览列表逻辑
        emit SigUpPreList(item);
    }

    emit SigSelectItem(item);

    auto * next_item = tree_item->GetNextItem();        //双缓冲，找下一个Item
    if(!next_item){
        return;
    }

    auto next_path = next_item->GetPath();
    _pixmap2.load(next_path);                           //图片2加载
    if(_map_items.find(next_path) == _map_items.end()){
         _map_items[next_path] = next_item;
         //发送更新预览列表逻辑
         emit SigUpPreList(next_item);
    }

}

//当点击预览图是触发
void PicAnimationWid::UpSelectPixmap(QTreeWidgetItem *item)
{
    if(!item){
        return;
    }

    auto * tree_item = dynamic_cast<ProTreeItem*>(item);
    auto path = tree_item->GetPath();       //获取路径
    _pixmap1.load(path);                    //加载图片
    _cur_item = tree_item;                  //更新当前item
    if(_map_items.find(path) == _map_items.end()){      //集合中不存在
        _map_items[path]=tree_item;                     //存入当前item
        qDebug() << "SetPixmap path is " << path << endl;
    }

    auto * next_item = tree_item->GetNextItem();        //获取下一个item
    if(!next_item){
        return;
    }

    auto next_path = next_item->GetPath();
    _pixmap2.load(next_path);                           //图片2加载
    if(_map_items.find(next_path) == _map_items.end()){
         _map_items[next_path] = next_item;
    }

}


//绘图事件
void PicAnimationWid::paintEvent(QPaintEvent *event)
{
    if(_pixmap1.isNull()){
        return;
    }

    QPainter painter(this);     //加载画刷
    painter.setRenderHint(QPainter::Antialiasing, true);    //渲染效果更好

    QRect rect = geometry();        //获取绘制区域

    int w = rect.width();
    int h = rect.height();
    _pixmap1=_pixmap1.scaled(w,h,Qt::KeepAspectRatio);      //等比拉伸

    int alpha = 255 * (1.0f - _factor);                     //更新factor，然后成为一个遮罩
    //qDebug()<<"_pixmap1.size()" << _pixmap1.size() << endl;

    //填充一个图片大小的透明图
    QPixmap alphaPixmap(_pixmap1.size());
    alphaPixmap.fill(Qt::transparent);

    //在透明图像上加载_pixmap1
   QPainter p1(&alphaPixmap);   //创建一个画刷对象，然后设置绘制目标为alphaPixmap
   p1.setCompositionMode(QPainter::CompositionMode_Source); //绘制方法
   p1.drawPixmap(0, 0, _pixmap1);   //画图片到alpha中，也就是起始图片
   p1.setCompositionMode(QPainter::CompositionMode_DestinationIn);
   p1.fillRect(alphaPixmap.rect(), QColor(0, 0, 0, alpha));
   //画目的图片，填充一个黑色的透明度作为遮罩，最后达到完全遮盖图片
   p1.end();

   int x = (w - _pixmap1.width()) / 2;
   int y = (h - _pixmap1.height()) / 2;
   painter.drawPixmap(x, y, alphaPixmap);   //把alpha绘制到painter上

   if(_pixmap2.isNull()){
        return;
   }

   //加载图片2并绘画
   _pixmap2=_pixmap2.scaled(w,h,Qt::KeepAspectRatio);
   alpha = 255 * (_factor);     //两个透明度刚好相反，一个透明度为0时另一个完全看不见
   QPixmap alphaPixmap2(_pixmap2.size());
   alphaPixmap2.fill(Qt::transparent);
   QPainter p2(&alphaPixmap2);
   p2.setCompositionMode(QPainter::CompositionMode_Source);
   p2.drawPixmap(0, 0, _pixmap2);
   p2.setCompositionMode(QPainter::CompositionMode_DestinationIn);
   p2.fillRect(alphaPixmap2.rect(), QColor(0, 0, 0, alpha));
   p2.end();
    x = (w - _pixmap2.width()) / 2;
    y = (h - _pixmap2.height()) / 2;
    painter.drawPixmap(x, y, alphaPixmap2);     //画出2
}

void PicAnimationWid::SlotStartOrStop()
{
    if(!_b_start){
        //当前没开始
        qDebug()<< "SlotStartOrStop begin start" << endl;
        _factor = 0;        //设置因子为0
        _timer->start(25);
        _b_start = true;    //改为开始
        emit SigStartMusic();
    }else{
        qDebug()<< "SlotStartOrStop begin stop" << endl;
        _timer->stop();     //定时器关闭
        _factor = 0;        //因子从0开始
        update();           //更新图片显示
        _b_start = false;   //改为暂停
        emit SigStopMusic();
    }

}

//实现点击预览图片主图片也切换
void PicAnimationWid::SlotUpSelectShow(QString path)
{
    qDebug()<<"SlotUpSelectShow path is " << path << endl;
    auto iter = _map_items.find(path);      //根据路径从集合中获取他的图片item，也就是value
    if(iter == _map_items.end()){
            return;
    }

    UpSelectPixmap(iter.value());
    update();
}

void PicAnimationWid::Start()
{
     emit SigStart();
     emit SigStartMusic();
    _factor = 0;
    _timer->start(25);
    _b_start = true;
}

void PicAnimationWid::Stop()
{
    emit SigStop();
    emit SigStopMusic();
    _timer->stop();
    _factor = 0;
    _b_start = false;
    //update();
}

void PicAnimationWid::SlideNext()       //向后滑动动画
{
    Stop();
    if(!_cur_item){
        return;
    }

    auto * cur_pro_item = dynamic_cast<ProTreeItem*>(_cur_item);
    auto * next_item = cur_pro_item->GetNextItem();         //获取下一个item节点
    if(!next_item){
        return;
    }
    SetPixmap(next_item);   //把下一个item设置成图片形式
    update();               //刷新widget动画图片才会显示
}

void PicAnimationWid::SlidePre()            //向前滑动动画
{
    Stop();
    if(!_cur_item){
        return;
    }

    auto * cur_pro_item = dynamic_cast<ProTreeItem*>(_cur_item);
    auto * pre_item = cur_pro_item->GetPreItem();
    if(!pre_item){
        return;
    }

    SetPixmap(pre_item);
    update();
}

void PicAnimationWid::TimeOut()
{
    if(!_cur_item){
        Stop();     //停止动画
        update();   //更新动画
        return;
    }
    //qDebug()<<"_factor is " << _factor << endl;

    _factor = _factor+0.01;

    if(_factor >= 1){   //当前的播放完
        _factor = 0;
        auto * cur_pro_item = dynamic_cast<ProTreeItem*>(_cur_item);    //当前item存为上一个item
        auto * next_pro_item = cur_pro_item->GetNextItem();             //同时获取下一个item
        if(!next_pro_item){
            Stop();
            update();
            return;
        }
        SetPixmap(next_pro_item);
        update();
        return;
    }
    update();
}
