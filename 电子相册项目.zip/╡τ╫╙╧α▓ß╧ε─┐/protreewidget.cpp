#include "protreewidget.h"
#include <QHeaderView>
#include <QDebug>
#include <QGuiApplication>
#include <QMenu>
#include <QDir>
#include "protreeitem.h"
#include "const.h"
#include <QFileDialog>
#include <QFileInfo>
#include <QFile>
#include <QProgressDialog>
#include <QVector>
#include <QMessageBox>
#include "removeprodialog.h"
#include <QApplication>
#include "protreethread.h"
#include "opentreethread.h"
#include "slideshowdlg.h"


ProTreeWidget::ProTreeWidget(QWidget *parent ):QTreeWidget (parent),_right_btn_item(nullptr),
    _active_item(nullptr),_selected_item(nullptr),_open_progressdlg(nullptr),_slide_show_dlg(nullptr)
{
    qRegisterMetaType<QVector<int> >("QVector<int>");
    //隐藏表头
    this->header()->hide();
    //itempress是随便在treewidget点击一下，就会触发，然后执行此槽函数
    connect(this, &ProTreeWidget::itemPressed, this, &ProTreeWidget::SlotItemPressed);

    //双击protree中的item，执行双击槽函数
    connect(this, &ProTreeWidget::itemDoubleClicked, this, &ProTreeWidget::SlotDoubleClickItem);

    //为各个动作具体设置，以及连接槽函数
    _action_import = new QAction(QIcon(":/icon/import.png"),tr("导入文件"), this);
    connect(_action_import, &QAction::triggered, this, &ProTreeWidget::SlotImport);

    _action_setstart = new QAction(QIcon(":/icon/core.png"), tr("设置活动项目"),this);
    connect(_action_setstart, &QAction::triggered, this, &ProTreeWidget::SlotSetActive);

    _action_closepro = new QAction(QIcon(":/icon/close.png"), tr("关闭项目"), this);
    connect(_action_closepro, &QAction::triggered, this, &ProTreeWidget::SlotClosePro);

    _action_slideshow = new QAction(QIcon(":/icon/slideshow.png"), tr("轮播图播放"),this);
    connect(_action_slideshow, &QAction::triggered, this, &ProTreeWidget::SlotSlideShow);


    _player = new QMediaPlayer(this);
    _playlist = new QMediaPlaylist(this);
    _playlist->setPlaybackMode(QMediaPlaylist::Loop);//设置循环模式
    _player->setPlaylist(_playlist);//获取将播放列表要播放的文件

}


//要实现向导页传输给mainwin后，然后调用这个函数，根据文件和名字创建文件夹并显示的功能
void ProTreeWidget::AddProToTree(const QString &name, const QString &path)
{
    qDebug() << "ProTreeWidget::AddProToTree name is " << name << " path is " << path << endl;

    QDir dir(path);
    QString file_path = dir.absoluteFilePath(name);
    //检测重名，判断路径和名字都一样则拒绝加入
    if(_set_path.find(file_path) != _set_path.end()){
        qDebug() << "file has loaded" << endl;
        return;
    }
    //构造项目用的文件夹
    QDir pro_dir(file_path);
    //如果文件夹不存在则创建
    if(!pro_dir.exists()){
        bool enable = pro_dir.mkpath(file_path);        //递归创建所有不存在的目录，从顶层一直创建到最下面，返回bool
        if(!enable){
            qDebug() << "pro_dir make path failed" << endl;
            return;
        }
    }

    _set_path.insert(file_path);    //重名集合中加入此路径和名字
    auto * item = new ProTreeItem(this, name, file_path,  TreeItemPro);
    item->setData(0,Qt::DisplayRole, name);
    item->setData(0,Qt::DecorationRole, QIcon(":/icon/dir.png"));
    item->setData(0,Qt::ToolTipRole, file_path);
}

ProTreeWidget::~ProTreeWidget()
{
    _player->stop();
}


void ProTreeWidget::SlotItemPressed(QTreeWidgetItem *pressedItem, int column)
{
    qDebug() << "ProTreeWidget::SlotItemPressed" << endl;
    if(QGuiApplication::mouseButtons() == Qt::RightButton)   //判断是否为右键，是就弹出一个菜单
        {
            QMenu menu(this);
            qDebug() << "menu addr is " << &menu << endl;
            int itemtype = (int)(pressedItem->type());      //获取对象的类型
            if (itemtype == TreeItemPro)                    //如果是根文件
            {
                _right_btn_item = pressedItem;      //把点击的item项赋值给此item
                //给widget的menu添加动作
                menu.addAction(_action_import);
                menu.addAction(_action_setstart);
                menu.addAction(_action_closepro);
                menu.addAction(_action_slideshow);      //轮播器播放
                menu.exec(QCursor::pos());   //菜单弹出位置为鼠标点击位置
            }
    }
}

void ProTreeWidget::SlotDoubleClickItem(QTreeWidgetItem* doubleItem, int col){
    qDebug() << "ProTreeWidget::SlotDoubleClickItem" << endl;

    if(QGuiApplication::mouseButtons() == Qt::LeftButton)   //判断是否为左键
        {
            auto * tree_doubleItem = dynamic_cast<ProTreeItem*>(doubleItem);    //类型转换
            if(!tree_doubleItem){   //没有Item存在
                return;
            }
            int itemtype = (int)(tree_doubleItem->type());      //item类型
            if(itemtype == TreeItemPic){        //如果是图片item
                emit SigUpdateSelected(tree_doubleItem->GetPath());     //发送更新选择的item并携带item路径信号
                _selected_item = doubleItem;
            }
    }
}

//导入文件的槽函数
void ProTreeWidget::SlotImport()
{
    QFileDialog file_dialog;
    file_dialog.setFileMode(QFileDialog::Directory);    //文件夹
    file_dialog.setWindowTitle("选择导入的文件夹");
    QString path = "";
    if(!_right_btn_item){       //点击后为空
        qDebug() << "_right_btn_item is empty" << endl;
        path = QDir::currentPath();     //设置路径
        return ;
    }

    path = dynamic_cast<ProTreeItem*>(_right_btn_item)->GetPath();      //获取点击对象的路径

    file_dialog.setDirectory(path);
    file_dialog.setViewMode(QFileDialog::Detail);

    QStringList fileNames;
    if (file_dialog.exec()){
          fileNames = file_dialog.selectedFiles();    //获取选择的文件路径
    }

    if(fileNames.length() <= 0){
        return;
    }

    QString import_path = fileNames.at(0);
    // qDebug() << "import_path is " << import_path << endl;
    int file_count = 0;

    //创建模态进度对话框
    _dialog_progress = new QProgressDialog(this);

    //耗时操作放在线程中操作
    //穿插拷贝文件线程，参数尽量使用引用传递，std::ref，线程的传递参数是右值（引用）
    _thread_create_pro = std::make_shared<ProTreeThread>(std::ref(import_path), std::ref(path),
                                                       _right_btn_item,
                                                       std::ref(file_count), this,_right_btn_item,nullptr);

    //连接更新进度框操作
    connect(_thread_create_pro.get(), &ProTreeThread::SigUpdateProgress,
           this, &ProTreeWidget::SlotUpdateProgress);
    //使用get因为连接的是裸指针，因为这个进程当初设置的是智能指针，因此需要通过get获得<>中的指针类型

    connect(_thread_create_pro.get(), &ProTreeThread::SigFinishProgress, this,
           &ProTreeWidget::SlotFinishProgress);

    connect(_dialog_progress, &QProgressDialog::canceled, this, &ProTreeWidget::SlotCancelProgress);    //对话框发送取消信号到widget，然后取消对话框

    connect(this, &ProTreeWidget::SigCancelProgress, _thread_create_pro.get(),
           &ProTreeThread::SlotCancelProgress);         //同时需要发送信号通知线程取消拷贝文件

    _thread_create_pro->start();        //启动线程

    //连接信号和槽
    _dialog_progress->setWindowTitle("Please wait...");
    _dialog_progress->setFixedWidth(PROGRESS_WIDTH);
    _dialog_progress->setRange(0, PROGRESS_MAX);
    _dialog_progress->exec();
}

//关闭项目的槽函数
void ProTreeWidget::SlotClosePro()
{
    RemoveProDialog  remove_pro_dialog;
    auto res = remove_pro_dialog.exec();
    bool b_remove = remove_pro_dialog.IsRemoved();      //判断勾选的状态
    auto index_right_btn = this->indexOfTopLevelItem(_right_btn_item);      //通过右键的条目获取他的索引
    auto * protreeitem = dynamic_cast<ProTreeItem*>(_right_btn_item);       //当前右键的条目
    auto * selecteditem = dynamic_cast<ProTreeItem*>(_selected_item);       //选择的条目

    auto delete_path = protreeitem->GetPath();
     qDebug() << "remove project from path: " << delete_path;
    _set_path.remove(delete_path);      //之前的路径保留在_set_path中，从集合中删除

    //是否删除本地文件
    if(b_remove){
       QDir delete_dir(delete_path);    //构造目录进行递归删除文件
       delete_dir.removeRecursively();
    }

    if(protreeitem == _active_item){    //如果是活动条目
        _active_item = nullptr;
    }

    if(selecteditem && protreeitem == selecteditem->GetRoot()){
        //判断如果选择的item存在 且 此item的根节点刚好为当前右键打算关闭项目的根节点
        selecteditem = nullptr;
         _selected_item = nullptr;
        emit SigClearSelected();
    }

    delete this->takeTopLevelItem(index_right_btn);     //删除他在目录树的索引
    _right_btn_item = nullptr;

}

void ProTreeWidget::SlotSlideShow(){
    if(!_right_btn_item){
        return;
    }
    auto *right_pro_item = dynamic_cast<ProTreeItem*>(_right_btn_item);

    auto * last_child_item = right_pro_item->GetLastPicChild();     //取出最后一个item子节点
    if(!last_child_item){
        return;
    }

    qDebug()<< "last child item name is " << last_child_item->GetPath()<< endl;

    auto * first_child_item = right_pro_item->GetFirstPicChild();   //取出第一个item子节点，也就是具体的图片文件
    if(!first_child_item){
        return;
    }

    qDebug()<< "first child item name is " << first_child_item->GetPath()<< endl;

    _slide_show_dlg = std::make_shared<SlideShowDlg>(this, first_child_item, last_child_item);      //设置滑动对话框
    _slide_show_dlg->setModal(true);    //设置对话框为模态类型
    _slide_show_dlg->showMaximized();   //最大化

}


void ProTreeWidget::SlotSetActive()
{
    if(!_right_btn_item){
        return;
    }

    QFont nullFont;
    nullFont.setBold(false);
    if(_active_item){
        _active_item->setFont(0,nullFont);      //把之前的活动项目字体设置为普通
    }

    _active_item = _right_btn_item;         //把当前右击的项目设置为活动项目
    nullFont.setBold(true);
    _active_item->setFont(0,nullFont);

}

void ProTreeWidget::SlotUpdateProgress(int count)
{
    qDebug() << "count is " << count;
    if(!_dialog_progress){
        qDebug() << "dialog_progress is empty!!!" << endl;
        return;
    }

    if(count >= PROGRESS_MAX){
         _dialog_progress->setValue(count%PROGRESS_MAX);
    }else{
         _dialog_progress->setValue(count%PROGRESS_MAX);
    }

}

void ProTreeWidget::SlotCancelProgress()
{
  //  _thread_create_pro->terminate();
    emit SigCancelProgress();       //发送这个信号通知线程
    delete _dialog_progress;
    _dialog_progress =nullptr;
}

void ProTreeWidget::SlotFinishProgress()
{
    _dialog_progress->setValue(PROGRESS_MAX);
    _dialog_progress->deleteLater();    //然后删除对话框
}

void ProTreeWidget::SlotUpOpenProgress(int count)
{
    if(!_open_progressdlg){
        return;
    }
    //qDebug()<<"SlotUpOpenProgress count is " << count;
    if(count >= PROGRESS_MAX){
         _open_progressdlg->setValue(count%PROGRESS_MAX);
    }else{
         _open_progressdlg->setValue(count%PROGRESS_MAX);
    }
}

void ProTreeWidget::SlotCancelOpenProgress()
{

}

void ProTreeWidget::SlotFinishOpenProgress()
{
    if(!_open_progressdlg){
        return;
    }
    _open_progressdlg->setValue(PROGRESS_MAX);
    delete  _open_progressdlg;
    _open_progressdlg = nullptr;
}

void ProTreeWidget::SlotPreShow(){
    if(!_selected_item){
        return;
    }

    //把_select_item转换为子类类型，并获取他的前一个item
    auto * curItem = dynamic_cast<ProTreeItem*>(_selected_item)->GetPreItem();
    if(!curItem){
        return;
    }
    emit SigUpdatePic(curItem->GetPath());
    _selected_item = curItem;
    this->setCurrentItem(curItem);
}
void ProTreeWidget::SlotNextShow(){

    if(!_selected_item){
        return;
    }

    auto * curItem = dynamic_cast<ProTreeItem*>(_selected_item)->GetNextItem();
    if(!curItem){
        return;
    }
    emit SigUpdatePic(curItem->GetPath());      //发送信号给picshow图片已更新，并携带当前item路径
    _selected_item = curItem;
    this->setCurrentItem(curItem);              //设置当前item被激活
}

//打开项目的槽函数
void ProTreeWidget::SlotOpenPro(const QString& path)
{
    if(_set_path.find(path) != _set_path.end()){
        qDebug() << "file has loaded" << endl;
        return;
    }

    _set_path.insert(path);
    int file_count = 0;
    QDir pro_dir(path);
    const QString& proname = pro_dir.dirName();

    _thread_open_pro = std::make_shared<OpenTreeThread>(path, file_count, this,nullptr);    //构造线程
    _thread_open_pro->start();

    _open_progressdlg = new QProgressDialog(this);

    //连接更新进度框操作
    connect(_thread_open_pro.get(), &OpenTreeThread::SigUpdateProgress,
            this, &ProTreeWidget::SlotUpOpenProgress);

    connect(_thread_open_pro.get(), &OpenTreeThread::SigFinishProgress, this,
            &ProTreeWidget::SlotFinishOpenProgress);

    _open_progressdlg->setWindowTitle("Please wait...");
    _open_progressdlg->setFixedWidth(PROGRESS_WIDTH);
    _open_progressdlg->setRange(0, PROGRESS_MAX);
    _open_progressdlg->exec();

}

void ProTreeWidget::SlotSetMusic(bool)
{
    qDebug() << "SlotSetMusic" <<endl;
    QFileDialog file_dialog;
    file_dialog.setFileMode(QFileDialog::ExistingFiles);
    file_dialog.setWindowTitle("选择导入的文件夹");

    file_dialog.setDirectory(QDir::currentPath());
    file_dialog.setViewMode(QFileDialog::Detail);
    file_dialog.setNameFilter("(*.mp3)");

    QStringList fileNames;
    if (file_dialog.exec()){
         fileNames = file_dialog.selectedFiles();   //返回文件对话框选中的文件路径列表
    }else{      //没有选择
        return;
    }

//    if(fileNames.length() <= 0){
//          return;
//    }

    _playlist->clear();     //清空

    for(auto filename : fileNames){     //获取每个文件路径
        qDebug() << "filename is " << filename << endl;
        _playlist->addMedia(QUrl::fromLocalFile(filename));     //添加到播放列表
    }

    if(_player->state()!=QMediaPlayer::PlayingState)        //判断是不是播放状态
      {
          _playlist->setCurrentIndex(0);        //设置静止
      }


}

void ProTreeWidget::SlotStartMusic()
{
    qDebug()<< "ProTreeWidget::SlotStartMusic" << endl;
     _player->play();
}



void ProTreeWidget::SlotStopMusic()
{
    qDebug()<< "ProTreeWidget::SlotStopMusic" << endl;
     _player->pause();
}


