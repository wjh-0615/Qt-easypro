#include "picbutton.h"
#include <QEvent>
PicButton::PicButton(QWidget *parent)
{

}

void PicButton::SetIcons(const QString &normal, const QString &hover, const QString &pressed)
{
    _normal = normal;     //正常状态下图片路径
    _hover = hover;       //悬浮状态下图片路径
    _pressed = pressed;   //点击时的图片路径

    QPixmap tmpPixmap;                          //图片临时变量
    tmpPixmap.load(normal);                     //按照normal状态下路径加载这些图片
    this->resize(tmpPixmap.size());
    this->setIcon(tmpPixmap);                   //将图标设置到当前对象
    this->setIconSize(tmpPixmap.size());        //保证icon图标和图片大小一致
}

//正常状态下图片函数
void PicButton::setNormalIcon(){
    QPixmap tmpPixmap;
    tmpPixmap.load(_normal);
    this->setIcon(tmpPixmap);
}

void PicButton::setHoverIcon(){
    QPixmap tmpPixmap;
    tmpPixmap.load(_hover);
    this->setIcon(tmpPixmap);
}

void PicButton::setPressIcon(){
    QPixmap tmpPixmap;
    tmpPixmap.load(_pressed);
    this->setIcon(tmpPixmap);
}

bool PicButton::event(QEvent *event)
{
    switch (event->type())
    {
    case QEvent::Enter:     //是鼠标滑动到上面的事件
        setHoverIcon();     //图标为悬浮
        break;
    case QEvent::Leave:
        setNormalIcon();
        break;
    case QEvent::MouseButtonPress:
        setPressIcon();
        break;
    case QEvent::MouseButtonRelease:
        setHoverIcon();
        break;
    default:
        break;
    }
    return QPushButton::event(event);   //调用基类的函数功能
}
