#ifndef PICSHOW_H
#define PICSHOW_H

#include <QDialog>
#include <QPixmap>
#include <QPropertyAnimation>       //属性动画
#include <QGraphicsOpacityEffect>   //透明度的变化
class ProTreeItem;
namespace Ui {
class PicShow;
}

class PicShow : public QDialog
{
    Q_OBJECT

public:
    explicit PicShow(QWidget *parent = nullptr);
    ~PicShow();
    void ReloadPic();
protected:
     bool event(QEvent *e) override;
private:
    void ShowPreNextBtns(bool b_show);      //设置显示函数

    Ui::PicShow *ui;
    QString _selected_path;     //存储选中的文件路径
    QPixmap _pix_map;           //存储图片
    QPropertyAnimation *_animation_show_pre;
    QPropertyAnimation *_animation_show_next;

    bool _b_btnvisible;     //保存当前按钮显示与否的状态
public slots:
    void SlotSelectItem(const QString& path);
    void SlotDeleteItem();
    void SlotUpdatePic(const QString& _path);

signals:
   void SigPreClicked();
   void SigNextClicked();
};

#endif // PICSHOW_H
