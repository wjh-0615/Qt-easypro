#include "wizard.h"
#include "ui_wizard.h"
#include <QDebug>
#include <QMessageBox>

Wizard::Wizard(QWidget *parent) :
    QWizard(parent),
    ui(new Ui::Wizard)
{
    ui->setupUi(this);
}

Wizard::~Wizard()
{
    delete ui;
}

void Wizard::done(int result)       //向导页完成后的操作
{
    if(result == QDialog::Rejected){
        return QWizard::done(result);
    }

    QString name, path;
    ui->wizardPage1->GetProSettings(name, path);
    emit SigProSettings(name, path);        //把设置的路径和文件名传输
    QWizard::done(result);
}





